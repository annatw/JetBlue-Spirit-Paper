Legal
-----

.. include:: ../LICENSE.txt
