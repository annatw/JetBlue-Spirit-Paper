Introduction
============

.. include:: ../README.rst
   :start-after: docs-start
