"""Structuring of BLP results."""
