"""Economies underlying the BLP model."""
