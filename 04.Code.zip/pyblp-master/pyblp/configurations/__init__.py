"""Configuration classes."""
