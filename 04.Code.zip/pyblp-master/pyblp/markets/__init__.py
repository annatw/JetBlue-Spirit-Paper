"""Individual markets underlying the BLP model."""
